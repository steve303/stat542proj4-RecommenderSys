Source code to the recommender app contains:
server.R
ui.R
functions/system2.R

The following code below was sourced by :
https://github.com/pspachtholz/BookRecommender
funtions/similarity_measures.R
functions/helpers.R
functions/gr_algorithm.R
functions/cf_algorithm.R
css/movies.css


link to the app: https://steve303.shinyapps.io/RecommenderApp/